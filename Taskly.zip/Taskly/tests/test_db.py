import os
import tempfile
import unittest
from datetime import date

from taskly.db import Database


class DatabaseTests(unittest.TestCase):
    def setUp(self):
        tmp = tempfile.TemporaryDirectory()
        self.addCleanup(tmp.cleanup)
        self.db = Database(os.path.join(tmp.name, "nested", "tasks.db"))
        self.addCleanup(self.db.close)

    def test_add_and_get(self):
        task = self.db.add("Отчёт", priority="high", due="2026-11-10", tags=["work", "Срочно"])
        loaded = self.db.get(task.id)
        self.assertEqual(loaded.title, "Отчёт")
        self.assertEqual(loaded.priority, "high")
        self.assertEqual(loaded.due, "2026-11-10")
        self.assertEqual(loaded.tags, ["work", "Срочно"])
        self.assertFalse(loaded.done)

    def test_get_missing_returns_none(self):
        self.assertIsNone(self.db.get(999))

    def test_ids_are_not_reused(self):
        first = self.db.add("a")
        self.db.delete(first.id)
        second = self.db.add("b")
        self.assertGreater(second.id, first.id)

    def test_status_filter(self):
        a = self.db.add("a")
        b = self.db.add("b")
        self.db.update(b.id, done=True)
        self.assertEqual([t.id for t in self.db.list_tasks()], [a.id])
        self.assertEqual([t.id for t in self.db.list_tasks(status="done")], [b.id])
        self.assertEqual(len(self.db.list_tasks(status="all")), 2)

    def test_priority_and_tag_filters(self):
        self.db.add("a", priority="high", tags=["Work"])
        self.db.add("b", priority="low", tags=["home"])
        self.assertEqual([t.title for t in self.db.list_tasks(priority="high")], ["a"])
        self.assertEqual([t.title for t in self.db.list_tasks(tag="work")], ["a"])
        self.assertEqual(self.db.list_tasks(tag="none"), [])

    def test_overdue_filter(self):
        self.db.add("old", due="2026-01-01")
        self.db.add("future", due="2099-01-01")
        self.db.add("no due")
        overdue = self.db.list_tasks(overdue=True, today=date(2026, 11, 4))
        self.assertEqual([t.title for t in overdue], ["old"])

    def test_sorting(self):
        self.db.add("no due")
        self.db.add("later", due="2026-12-01")
        self.db.add("soon low", due="2026-11-01", priority="low")
        self.db.add("soon high", due="2026-11-01", priority="high")
        titles = [t.title for t in self.db.list_tasks()]
        self.assertEqual(titles, ["soon high", "soon low", "later", "no due"])

    def test_update_and_delete(self):
        task = self.db.add("a")
        updated = self.db.update(task.id, title="b", tags=["x"], due="2026-12-31")
        self.assertEqual((updated.title, updated.tags, updated.due), ("b", ["x"], "2026-12-31"))
        self.assertIsNone(self.db.update(999, title="z"))
        self.assertTrue(self.db.delete(task.id))
        self.assertFalse(self.db.delete(task.id))

    def test_update_rejects_unknown_fields(self):
        task = self.db.add("a")
        with self.assertRaises(ValueError):
            self.db.update(task.id, id=5)

    def test_add_many_is_atomic(self):
        good = {"title": "ok", "priority": "low", "tags": ["t"], "done": True}
        bad = {"priority": "low"}  # нет title -> KeyError
        with self.assertRaises(KeyError):
            self.db.add_many([good, bad])
        self.assertEqual(self.db.list_tasks(status="all"), [])
        self.assertEqual(self.db.add_many([good]), 1)
        self.assertTrue(self.db.list_tasks(status="all")[0].done)


if __name__ == "__main__":
    unittest.main()
