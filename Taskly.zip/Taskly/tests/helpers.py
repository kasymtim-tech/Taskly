"""Общие вспомогательные средства для тестов."""

import contextlib
import io
import os
import tempfile
import unittest
from unittest import mock

from taskly.cli import main


class CliTestCase(unittest.TestCase):
    """Каждый тест работает в своей временной «домашней» папке и со своей базой."""

    def setUp(self) -> None:
        tmp = tempfile.TemporaryDirectory()
        self.addCleanup(tmp.cleanup)
        self.tmp = tmp.name
        env = {
            "HOME": self.tmp,
            "USERPROFILE": self.tmp,
            "APPDATA": self.tmp,
            "TASKLY_DB": os.path.join(self.tmp, "tasks.db"),
        }
        patcher = mock.patch.dict(os.environ, env)
        patcher.start()
        self.addCleanup(patcher.stop)

    def run_cli(self, *argv: str) -> tuple[int, str, str]:
        out, err = io.StringIO(), io.StringIO()
        with contextlib.redirect_stdout(out), contextlib.redirect_stderr(err):
            try:
                code = main(list(argv))
            except SystemExit as exc:
                code = exc.code if isinstance(exc.code, int) else 1
        return code, out.getvalue(), err.getvalue()
