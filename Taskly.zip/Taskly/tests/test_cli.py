import csv
import json
import os
import unittest

from taskly import __version__
from tests.helpers import CliTestCase


class CliTests(CliTestCase):
    def test_version(self):
        code, out, _ = self.run_cli("--version")
        self.assertEqual(code, 0)
        self.assertEqual(out.strip(), f"taskly {__version__}")

    def test_command_is_required(self):
        code, _, _ = self.run_cli()
        self.assertEqual(code, 2)

    def test_add_and_list(self):
        code, out, _ = self.run_cli(
            "add", "Подготовить", "отчёт", "-p", "high", "-d", "2026-11-10", "-t", "work"
        )
        self.assertEqual(code, 0)
        self.assertIn("#1", out)
        code, out, _ = self.run_cli("list")
        self.assertEqual(code, 0)
        self.assertIn("Подготовить отчёт", out)
        self.assertIn("high", out)
        self.assertIn("2026-11-10", out)
        self.assertIn("work", out)
        self.assertIn("Всего: 1", out)

    def test_list_empty(self):
        code, out, _ = self.run_cli("list")
        self.assertEqual(code, 0)
        self.assertIn("Задач не найдено", out)

    def test_done_and_status_filter(self):
        self.run_cli("add", "a")
        self.run_cli("add", "b")
        code, out, _ = self.run_cli("done", "1")
        self.assertEqual(code, 0)
        self.assertIn("выполнена", out)
        _, out, _ = self.run_cli("list")
        self.assertIn("Всего: 1", out)
        self.assertNotIn("[x]", out)
        _, out, _ = self.run_cli("list", "--status", "done")
        self.assertIn("[x]", out)
        _, out, _ = self.run_cli("list", "--status", "all")
        self.assertIn("Всего: 2", out)

    def test_done_twice_is_not_an_error(self):
        self.run_cli("add", "a")
        self.run_cli("done", "1")
        code, out, _ = self.run_cli("done", "1")
        self.assertEqual(code, 0)
        self.assertIn("уже выполнена", out)

    def test_rm(self):
        self.run_cli("add", "a")
        code, out, _ = self.run_cli("rm", "1")
        self.assertEqual(code, 0)
        self.assertIn("удалена", out)
        code, _, err = self.run_cli("rm", "1")
        self.assertEqual(code, 1)
        self.assertIn("не найдена", err)

    def test_missing_task_errors(self):
        for command in (["done", "42"], ["rm", "42"], ["edit", "42", "--title", "x"]):
            with self.subTest(command=command):
                code, _, err = self.run_cli(*command)
                self.assertEqual(code, 1)
                self.assertIn("#42", err)

    def test_edit(self):
        self.run_cli("add", "a", "-d", "2026-11-10", "-t", "x")
        code, _, _ = self.run_cli(
            "edit", "1", "--title", "новое", "-p", "low", "-t", "y", "-t", "z"
        )
        self.assertEqual(code, 0)
        _, out, _ = self.run_cli("list")
        self.assertIn("новое", out)
        self.assertIn("low", out)
        self.assertIn("y, z", out)
        code, _, _ = self.run_cli("edit", "1", "--clear-due", "--clear-tags")
        self.assertEqual(code, 0)
        _, out, _ = self.run_cli("list")
        self.assertNotIn("2026-11-10", out)
        self.assertNotIn("y, z", out)

    def test_edit_without_changes_is_an_error(self):
        self.run_cli("add", "a")
        code, _, err = self.run_cli("edit", "1")
        self.assertEqual(code, 1)
        self.assertIn("Укажите", err)

    def test_invalid_input_is_rejected(self):
        self.assertEqual(self.run_cli("add", "a", "-d", "10.11.2026")[0], 2)
        self.assertEqual(self.run_cli("add", "a", "-p", "urgent")[0], 2)
        self.assertEqual(self.run_cli("done", "abc")[0], 2)
        self.assertEqual(self.run_cli("done", "0")[0], 2)
        code, _, err = self.run_cli("add", "   ")
        self.assertEqual(code, 1)
        self.assertIn("пустым", err)

    def test_filters(self):
        self.run_cli("add", "просрочено", "-d", "2000-01-01", "-p", "high", "-t", "work")
        self.run_cli("add", "в будущем", "-d", "2999-01-01", "-p", "low", "-t", "home")
        _, out, _ = self.run_cli("list", "--overdue")
        self.assertIn("просрочено", out)
        self.assertNotIn("в будущем", out)
        _, out, _ = self.run_cli("list", "--priority", "low")
        self.assertIn("в будущем", out)
        self.assertNotIn("просрочено", out)
        _, out, _ = self.run_cli("list", "--tag", "WORK")
        self.assertIn("просрочено", out)
        self.assertNotIn("в будущем", out)

    def test_export_and_import_json(self):
        self.run_cli(
            "add", "Задача, с запятой", "-p", "high", "-d", "2026-11-10", "-t", "a", "-t", "b"
        )
        self.run_cli("add", "вторая")
        self.run_cli("done", "2")
        path = os.path.join(self.tmp, "tasks.json")
        code, out, _ = self.run_cli("export", path)
        self.assertEqual(code, 0)
        self.assertIn("2", out)
        with open(path, encoding="utf-8") as file:
            data = json.load(file)
        self.assertEqual([item["title"] for item in data], ["Задача, с запятой", "вторая"])
        self.assertEqual(data[0]["tags"], ["a", "b"])
        self.assertTrue(data[1]["done"])

        os.remove(os.environ["TASKLY_DB"])
        code, out, _ = self.run_cli("import", path)
        self.assertEqual(code, 0)
        self.assertIn("2", out)
        _, out, _ = self.run_cli("list", "--status", "all")
        self.assertIn("Задача, с запятой", out)
        self.assertIn("Всего: 2", out)

    def test_export_and_import_csv(self):
        self.run_cli("add", "a;b", "-t", "x", "-t", "y")
        path = os.path.join(self.tmp, "tasks.csv")
        self.assertEqual(self.run_cli("export", path)[0], 0)
        with open(path, newline="", encoding="utf-8") as file:
            rows = list(csv.DictReader(file))
        self.assertEqual(rows[0]["tags"], "x;y")
        self.assertEqual(rows[0]["done"], "false")
        self.assertEqual(self.run_cli("import", path)[0], 0)
        _, out, _ = self.run_cli("list", "--status", "all")
        self.assertIn("Всего: 2", out)

    def test_import_is_all_or_nothing(self):
        path = os.path.join(self.tmp, "bad.json")
        with open(path, "w", encoding="utf-8") as file:
            json.dump([{"title": "ok"}, {"title": "bad", "priority": "urgent"}], file)
        code, _, err = self.run_cli("import", path)
        self.assertEqual(code, 1)
        self.assertIn("запись 2", err)
        _, out, _ = self.run_cli("list", "--status", "all")
        self.assertIn("Задач не найдено", out)

    def test_import_errors(self):
        missing = os.path.join(self.tmp, "missing.json")
        self.assertEqual(self.run_cli("import", missing)[0], 1)
        wrong = os.path.join(self.tmp, "data.txt")
        self.assertEqual(self.run_cli("import", wrong)[0], 1)
        broken = os.path.join(self.tmp, "broken.json")
        with open(broken, "w", encoding="utf-8") as file:
            file.write("{not json")
        code, _, err = self.run_cli("import", broken)
        self.assertEqual(code, 1)
        self.assertIn("JSON", err)

    def test_export_rejects_unknown_extension(self):
        code, _, err = self.run_cli("export", os.path.join(self.tmp, "tasks.xml"))
        self.assertEqual(code, 1)
        self.assertIn(".json", err)


if __name__ == "__main__":
    unittest.main()
