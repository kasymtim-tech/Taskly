import os
import unittest
from pathlib import Path
from unittest import mock

from taskly.config import ConfigError, config_path, load_config
from tests.helpers import CliTestCase


class ConfigTests(CliTestCase):
    def test_default_config_is_created_on_first_run(self):
        path = config_path()
        self.assertFalse(path.exists())
        config = load_config()
        self.assertTrue(path.exists())
        text = path.read_text(encoding="utf-8")
        self.assertIn("[general]", text)
        self.assertIn("[display]", text)
        self.assertTrue(config.color)
        self.assertEqual(config.date_format, "%Y-%m-%d")

    def test_environment_overrides_database(self):
        self.assertEqual(load_config().database, Path(os.environ["TASKLY_DB"]))

    def test_database_from_file_when_env_is_not_set(self):
        path = config_path()
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(
            '[general]\ndatabase = "~/custom.db"\ndate_format = "%d.%m.%Y"\n'
            "[display]\ncolor = false\n",
            encoding="utf-8",
        )
        with mock.patch.dict(os.environ):
            del os.environ["TASKLY_DB"]
            config = load_config()
        self.assertEqual(config.database, Path(self.tmp) / "custom.db")
        self.assertEqual(config.date_format, "%d.%m.%Y")
        self.assertFalse(config.color)

    def test_broken_config_raises_config_error(self):
        path = config_path()
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text("[general\n", encoding="utf-8")
        with self.assertRaises(ConfigError):
            load_config()

    def test_wrong_type_raises_config_error(self):
        path = config_path()
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text('[display]\ncolor = "yes"\n', encoding="utf-8")
        with self.assertRaises(ConfigError):
            load_config()

    def test_cli_reports_config_error(self):
        path = config_path()
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text("[general\n", encoding="utf-8")
        code, _, err = self.run_cli("list")
        self.assertEqual(code, 1)
        self.assertIn("Ошибка", err)


if __name__ == "__main__":
    unittest.main()
