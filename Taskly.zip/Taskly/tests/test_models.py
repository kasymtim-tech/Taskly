import unittest
from datetime import date

from taskly.models import (
    Task,
    ValidationError,
    normalize_tags,
    parse_bool,
    validate_date,
    validate_priority,
    validate_title,
)


class ValidationTests(unittest.TestCase):
    def test_title_is_trimmed_and_collapsed(self):
        self.assertEqual(validate_title("  Купить   хлеб \n"), "Купить хлеб")

    def test_empty_title_is_rejected(self):
        with self.assertRaises(ValidationError):
            validate_title("   ")

    def test_priority_is_case_insensitive(self):
        self.assertEqual(validate_priority(" HIGH "), "high")

    def test_unknown_priority_is_rejected(self):
        with self.assertRaises(ValidationError):
            validate_priority("urgent")

    def test_date_is_normalized(self):
        self.assertEqual(validate_date("2026-1-5"), "2026-01-05")

    def test_invalid_dates_are_rejected(self):
        for value in ("10.11.2026", "2026-13-01", "2026-02-30", "завтра"):
            with self.subTest(value=value), self.assertRaises(ValidationError):
                validate_date(value)

    def test_tags_are_deduplicated_ignoring_case(self):
        self.assertEqual(normalize_tags(["Work", " work ", "", "home"]), ["Work", "home"])

    def test_parse_bool(self):
        self.assertTrue(parse_bool("True"))
        self.assertTrue(parse_bool("1"))
        self.assertFalse(parse_bool("false"))
        self.assertFalse(parse_bool(""))
        with self.assertRaises(ValidationError):
            parse_bool("может быть")


class TaskTests(unittest.TestCase):
    def test_overdue(self):
        today = date(2026, 11, 4)
        self.assertTrue(Task(1, "a", due="2026-11-03").is_overdue(today))
        self.assertFalse(Task(1, "a", due="2026-11-04").is_overdue(today))
        self.assertFalse(Task(1, "a", due="2026-11-03", done=True).is_overdue(today))
        self.assertFalse(Task(1, "a").is_overdue(today))


if __name__ == "__main__":
    unittest.main()
