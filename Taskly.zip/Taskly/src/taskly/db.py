"""Хранение задач в SQLite."""

from __future__ import annotations

import json
import sqlite3
from collections.abc import Iterable, Mapping
from datetime import date, datetime
from pathlib import Path
from types import TracebackType

from taskly.models import PRIORITY_RANK, Task

SCHEMA = """
CREATE TABLE IF NOT EXISTS tasks (
    id         INTEGER PRIMARY KEY AUTOINCREMENT,
    title      TEXT    NOT NULL,
    priority   TEXT    NOT NULL DEFAULT 'medium',
    due        TEXT,
    tags       TEXT    NOT NULL DEFAULT '[]',
    done       INTEGER NOT NULL DEFAULT 0,
    created_at TEXT    NOT NULL
)
"""

_UPDATABLE = frozenset({"title", "priority", "due", "tags", "done"})


def _now() -> str:
    return datetime.now().isoformat(timespec="seconds")


def _dump_tags(tags: Iterable[str]) -> str:
    return json.dumps(list(tags), ensure_ascii=False)


def _row_to_task(row: sqlite3.Row) -> Task:
    return Task(
        id=row["id"],
        title=row["title"],
        priority=row["priority"],
        due=row["due"],
        tags=json.loads(row["tags"]),
        done=bool(row["done"]),
        created_at=row["created_at"],
    )


def _sort_key(task: Task) -> tuple:
    # Сначала активные, потом по сроку (без срока — в конце), затем по приоритету и номеру.
    return (
        task.done,
        task.due is None,
        task.due or "",
        PRIORITY_RANK.get(task.priority, len(PRIORITY_RANK)),
        task.id,
    )


class Database:
    def __init__(self, path: str | Path) -> None:
        self.path = Path(path)
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self._conn = sqlite3.connect(self.path)
        self._conn.row_factory = sqlite3.Row
        with self._conn:
            self._conn.execute(SCHEMA)

    def close(self) -> None:
        self._conn.close()

    def __enter__(self) -> Database:
        return self

    def __exit__(
        self,
        exc_type: type[BaseException] | None,
        exc: BaseException | None,
        tb: TracebackType | None,
    ) -> None:
        self.close()

    def add(
        self,
        title: str,
        priority: str = "medium",
        due: str | None = None,
        tags: Iterable[str] = (),
    ) -> Task:
        tags = list(tags)
        created_at = _now()
        with self._conn:
            cursor = self._conn.execute(
                "INSERT INTO tasks (title, priority, due, tags, done, created_at) "
                "VALUES (?, ?, ?, ?, 0, ?)",
                (title, priority, due, _dump_tags(tags), created_at),
            )
        return Task(
            id=int(cursor.lastrowid or 0),
            title=title,
            priority=priority,
            due=due,
            tags=tags,
            created_at=created_at,
        )

    def add_many(self, records: Iterable[Mapping[str, object]]) -> int:
        """Добавляет задачи одной транзакцией: либо все, либо ни одной."""
        count = 0
        with self._conn:
            for record in records:
                self._conn.execute(
                    "INSERT INTO tasks (title, priority, due, tags, done, created_at) "
                    "VALUES (?, ?, ?, ?, ?, ?)",
                    (
                        record["title"],
                        record.get("priority") or "medium",
                        record.get("due"),
                        _dump_tags(record.get("tags") or []),  # type: ignore[arg-type]
                        int(bool(record.get("done", False))),
                        record.get("created_at") or _now(),
                    ),
                )
                count += 1
        return count

    def get(self, task_id: int) -> Task | None:
        row = self._conn.execute("SELECT * FROM tasks WHERE id = ?", (task_id,)).fetchone()
        return _row_to_task(row) if row else None

    def list_tasks(
        self,
        status: str = "active",
        priority: str | None = None,
        tag: str | None = None,
        overdue: bool = False,
        today: date | None = None,
    ) -> list[Task]:
        clauses: list[str] = []
        params: list[object] = []
        if status == "active":
            clauses.append("done = 0")
        elif status == "done":
            clauses.append("done = 1")
        if priority:
            clauses.append("priority = ?")
            params.append(priority)

        query = "SELECT * FROM tasks"
        if clauses:
            query += " WHERE " + " AND ".join(clauses)

        tasks = [_row_to_task(row) for row in self._conn.execute(query, params)]

        if tag:
            wanted = tag.strip().casefold()
            tasks = [t for t in tasks if wanted in (x.casefold() for x in t.tags)]
        if overdue:
            tasks = [t for t in tasks if t.is_overdue(today)]

        tasks.sort(key=_sort_key)
        return tasks

    def update(self, task_id: int, **fields: object) -> Task | None:
        unknown = set(fields) - _UPDATABLE
        if unknown:
            raise ValueError(f"Нельзя изменить поля: {', '.join(sorted(unknown))}")
        if not fields:
            return self.get(task_id)

        assignments: list[str] = []
        values: list[object] = []
        for key, value in fields.items():
            if key == "tags":
                value = _dump_tags(value)  # type: ignore[arg-type]
            elif key == "done":
                value = int(bool(value))
            assignments.append(f"{key} = ?")
            values.append(value)

        with self._conn:
            cursor = self._conn.execute(
                f"UPDATE tasks SET {', '.join(assignments)} WHERE id = ?",
                (*values, task_id),
            )
        if cursor.rowcount == 0:
            return None
        return self.get(task_id)

    def delete(self, task_id: int) -> bool:
        with self._conn:
            cursor = self._conn.execute("DELETE FROM tasks WHERE id = ?", (task_id,))
        return cursor.rowcount > 0
