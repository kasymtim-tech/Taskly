"""Экспорт и импорт задач в форматах JSON и CSV."""

from __future__ import annotations

import csv
import json
from collections.abc import Iterable
from pathlib import Path

from taskly.models import (
    Task,
    TasklyError,
    ValidationError,
    normalize_tags,
    parse_bool,
    validate_date,
    validate_priority,
    validate_title,
)

CSV_FIELDS = ["id", "title", "priority", "due", "tags", "done", "created_at"]


class TransferError(TasklyError):
    """Ошибка экспорта или импорта."""


def _file_format(path: Path) -> str:
    suffix = path.suffix.lower()
    if suffix not in {".json", ".csv"}:
        raise TransferError("Поддерживаются только файлы .json и .csv.")
    return suffix[1:]


def export_tasks(tasks: Iterable[Task], path: str | Path) -> int:
    target = Path(path).expanduser()
    file_format = _file_format(target)
    items = sorted(tasks, key=lambda task: task.id)

    if file_format == "json":
        payload = [task.to_dict() for task in items]
        target.write_text(
            json.dumps(payload, ensure_ascii=False, indent=2) + "\n", encoding="utf-8"
        )
    else:
        with target.open("w", newline="", encoding="utf-8") as file:
            writer = csv.DictWriter(file, fieldnames=CSV_FIELDS)
            writer.writeheader()
            for task in items:
                row = task.to_dict()
                row["tags"] = ";".join(task.tags)
                row["done"] = "true" if task.done else "false"
                writer.writerow(row)
    return len(items)


def _normalize_record(raw: object, where: str) -> dict[str, object]:
    if not isinstance(raw, dict):
        raise TransferError(f"{where}: ожидался объект с полями задачи.")
    try:
        title = validate_title(str(raw.get("title") or ""))
        priority = validate_priority(str(raw.get("priority") or "medium"))
        due_raw = raw.get("due")
        due = validate_date(str(due_raw)) if due_raw else None

        tags_raw = raw.get("tags") or []
        if isinstance(tags_raw, str):
            tags_raw = tags_raw.split(";")
        if not isinstance(tags_raw, list):
            raise ValidationError("поле tags должно быть списком или строкой через «;».")
        tags = normalize_tags(str(tag) for tag in tags_raw)

        done = parse_bool(raw.get("done", False))
    except ValidationError as exc:
        raise TransferError(f"{where}: {exc}") from None

    created_at = raw.get("created_at")
    return {
        "title": title,
        "priority": priority,
        "due": due,
        "tags": tags,
        "done": done,
        "created_at": str(created_at) if created_at else None,
    }


def import_tasks(path: str | Path) -> list[dict[str, object]]:
    """Читает и проверяет файл целиком. Ничего не записывает в базу."""
    source = Path(path).expanduser()
    file_format = _file_format(source)

    if file_format == "json":
        try:
            data = json.loads(source.read_text(encoding="utf-8-sig"))
        except json.JSONDecodeError as exc:
            raise TransferError(f"Некорректный JSON: {exc}") from None
        if not isinstance(data, list):
            raise TransferError("JSON должен содержать список задач.")
        return [_normalize_record(item, f"запись {number}") for number, item in enumerate(data, 1)]

    with source.open(newline="", encoding="utf-8-sig") as file:
        reader = csv.DictReader(file)
        if not reader.fieldnames or "title" not in reader.fieldnames:
            raise TransferError("В CSV-файле нет столбца title.")
        return [_normalize_record(row, f"строка {reader.line_num}") for row in reader]
