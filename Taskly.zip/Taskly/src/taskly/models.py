"""Модели данных и проверка значений."""

from __future__ import annotations

from collections.abc import Iterable
from dataclasses import dataclass, field
from datetime import date, datetime

PRIORITIES = ("low", "medium", "high")
PRIORITY_RANK = {"high": 0, "medium": 1, "low": 2}
DATE_FORMAT = "%Y-%m-%d"


class TasklyError(Exception):
    """Базовая ошибка приложения. Показывается пользователю без трассировки."""


class ValidationError(TasklyError):
    """Некорректное значение, введённое пользователем."""


@dataclass
class Task:
    id: int
    title: str
    priority: str = "medium"
    due: str | None = None
    tags: list[str] = field(default_factory=list)
    done: bool = False
    created_at: str = ""

    def is_overdue(self, today: date | None = None) -> bool:
        """Задача просрочена, если она не выполнена и срок раньше сегодняшнего дня."""
        if self.done or not self.due:
            return False
        return self.due < (today or date.today()).isoformat()

    def to_dict(self) -> dict[str, object]:
        return {
            "id": self.id,
            "title": self.title,
            "priority": self.priority,
            "due": self.due,
            "tags": list(self.tags),
            "done": self.done,
            "created_at": self.created_at,
        }


def validate_title(value: str) -> str:
    title = " ".join(value.split())
    if not title:
        raise ValidationError("Название задачи не может быть пустым.")
    return title


def validate_priority(value: str) -> str:
    priority = value.strip().lower()
    if priority not in PRIORITIES:
        raise ValidationError(
            f"Неизвестный приоритет «{value}». Допустимо: {', '.join(PRIORITIES)}."
        )
    return priority


def validate_date(value: str) -> str:
    text = value.strip()
    try:
        parsed = datetime.strptime(text, DATE_FORMAT)
    except ValueError:
        raise ValidationError(
            f"Неверная дата «{value}». Используйте формат ГГГГ-ММ-ДД, например 2026-11-10."
        ) from None
    return parsed.date().isoformat()


def normalize_tags(values: Iterable[str]) -> list[str]:
    """Убирает пробелы, пустые теги и повторы (без учёта регистра)."""
    result: list[str] = []
    seen: set[str] = set()
    for value in values:
        tag = value.strip()
        key = tag.casefold()
        if tag and key not in seen:
            seen.add(key)
            result.append(tag)
    return result


def parse_bool(value: object) -> bool:
    if isinstance(value, bool):
        return value
    text = str(value).strip().lower()
    if text in {"true", "1", "yes", "y", "да"}:
        return True
    if text in {"false", "0", "no", "n", "нет", ""}:
        return False
    raise ValidationError(f"Не удаётся преобразовать «{value}» в логическое значение.")
