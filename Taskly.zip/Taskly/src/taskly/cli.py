"""Интерфейс командной строки Taskly."""

from __future__ import annotations

import argparse
import os
import sqlite3
import sys
from collections.abc import Sequence
from datetime import date

from taskly import __version__
from taskly.config import Config, load_config
from taskly.db import Database
from taskly.formatting import render_table
from taskly.models import (
    PRIORITIES,
    Task,
    TasklyError,
    normalize_tags,
    validate_date,
    validate_title,
)
from taskly.transfer import export_tasks, import_tasks


def _date_arg(value: str) -> str:
    try:
        return validate_date(value)
    except TasklyError as exc:
        raise argparse.ArgumentTypeError(str(exc)) from None


def _id_arg(value: str) -> int:
    try:
        number = int(value)
    except ValueError:
        raise argparse.ArgumentTypeError(f"«{value}» не является номером задачи.") from None
    if number < 1:
        raise argparse.ArgumentTypeError("Номер задачи должен быть положительным.")
    return number


def _use_color(config: Config) -> bool:
    return config.color and sys.stdout.isatty() and not os.environ.get("NO_COLOR")


def _require_task(db: Database, task_id: int) -> Task:
    task = db.get(task_id)
    if task is None:
        raise TasklyError(f"Задача #{task_id} не найдена.")
    return task


def cmd_add(args: argparse.Namespace, db: Database, config: Config) -> int:
    title = validate_title(" ".join(args.title))
    task = db.add(
        title,
        priority=args.priority,
        due=args.due,
        tags=normalize_tags(args.tag or []),
    )
    print(f"Добавлена задача #{task.id}: {task.title}")
    return 0


def cmd_list(args: argparse.Namespace, db: Database, config: Config) -> int:
    tasks = db.list_tasks(
        status=args.status,
        priority=args.priority,
        tag=args.tag,
        overdue=args.overdue,
    )
    if not tasks:
        print("Задач не найдено.")
        return 0
    today = date.today()
    table = render_table(
        tasks, date_format=config.date_format, color=_use_color(config), today=today
    )
    print(table)
    print(f"\nВсего: {len(tasks)}")
    return 0


def cmd_edit(args: argparse.Namespace, db: Database, config: Config) -> int:
    task = _require_task(db, args.id)
    changes: dict[str, object] = {}
    if args.title is not None:
        changes["title"] = validate_title(args.title)
    if args.priority is not None:
        changes["priority"] = args.priority
    if args.due is not None:
        changes["due"] = args.due
    if args.clear_due:
        changes["due"] = None
    if args.clear_tags:
        changes["tags"] = []
    elif args.tag:
        changes["tags"] = normalize_tags(args.tag)

    if not changes:
        raise TasklyError(
            "Укажите, что изменить: --title, --priority, --due, --clear-due, --tag, --clear-tags."
        )
    db.update(task.id, **changes)
    print(f"Задача #{task.id} обновлена.")
    return 0


def cmd_done(args: argparse.Namespace, db: Database, config: Config) -> int:
    task = _require_task(db, args.id)
    if task.done:
        print(f"Задача #{task.id} уже выполнена.")
        return 0
    db.update(task.id, done=True)
    print(f"Задача #{task.id} выполнена: {task.title}")
    return 0


def cmd_rm(args: argparse.Namespace, db: Database, config: Config) -> int:
    task = _require_task(db, args.id)
    db.delete(task.id)
    print(f"Задача #{task.id} удалена: {task.title}")
    return 0


def cmd_export(args: argparse.Namespace, db: Database, config: Config) -> int:
    count = export_tasks(db.list_tasks(status="all"), args.file)
    print(f"Экспортировано задач: {count} → {args.file}")
    return 0


def cmd_import(args: argparse.Namespace, db: Database, config: Config) -> int:
    records = import_tasks(args.file)
    count = db.add_many(records)
    print(f"Импортировано задач: {count}")
    return 0


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="taskly",
        description="Taskly — быстрый менеджер задач для терминала.",
    )
    parser.add_argument("--version", action="version", version=f"taskly {__version__}")
    commands = parser.add_subparsers(dest="command", metavar="<команда>", required=True)

    def priority_arg(command: argparse.ArgumentParser, default: str | None) -> None:
        command.add_argument(
            "-p",
            "--priority",
            type=str.lower,
            choices=PRIORITIES,
            default=default,
            help="приоритет: low, medium или high",
        )

    add = commands.add_parser("add", help="создать задачу")
    add.add_argument("title", nargs="+", help="название задачи")
    priority_arg(add, "medium")
    add.add_argument("-d", "--due", type=_date_arg, metavar="ГГГГ-ММ-ДД", help="срок выполнения")
    add.add_argument("-t", "--tag", action="append", help="тег (можно указать несколько раз)")
    add.set_defaults(handler=cmd_add)

    show = commands.add_parser("list", help="показать задачи")
    show.add_argument(
        "--status",
        choices=("active", "done", "all"),
        default="active",
        help="какие задачи показывать (по умолчанию active)",
    )
    priority_arg(show, None)
    show.add_argument("-t", "--tag", help="показать задачи с этим тегом")
    show.add_argument("--overdue", action="store_true", help="только просроченные")
    show.set_defaults(handler=cmd_list)

    edit = commands.add_parser("edit", help="изменить задачу")
    edit.add_argument("id", type=_id_arg, help="номер задачи")
    edit.add_argument("--title", help="новое название")
    priority_arg(edit, None)
    due_group = edit.add_mutually_exclusive_group()
    due_group.add_argument("-d", "--due", type=_date_arg, metavar="ГГГГ-ММ-ДД", help="новый срок")
    due_group.add_argument("--clear-due", action="store_true", help="убрать срок")
    tag_group = edit.add_mutually_exclusive_group()
    tag_group.add_argument(
        "-t", "--tag", action="append", help="новый набор тегов (заменяет прежние)"
    )
    tag_group.add_argument("--clear-tags", action="store_true", help="убрать все теги")
    edit.set_defaults(handler=cmd_edit)

    done = commands.add_parser("done", help="отметить задачу выполненной")
    done.add_argument("id", type=_id_arg, help="номер задачи")
    done.set_defaults(handler=cmd_done)

    remove = commands.add_parser("rm", help="удалить задачу")
    remove.add_argument("id", type=_id_arg, help="номер задачи")
    remove.set_defaults(handler=cmd_rm)

    export = commands.add_parser("export", help="экспортировать задачи в .json или .csv")
    export.add_argument("file", help="путь к файлу")
    export.set_defaults(handler=cmd_export)

    imp = commands.add_parser("import", help="импортировать задачи из .json или .csv")
    imp.add_argument("file", help="путь к файлу")
    imp.set_defaults(handler=cmd_import)

    return parser


def main(argv: Sequence[str] | None = None) -> int:
    args = build_parser().parse_args(argv)
    try:
        config = load_config()
        with Database(config.database) as db:
            return args.handler(args, db, config)
    except (TasklyError, OSError, sqlite3.Error) as exc:
        print(f"Ошибка: {exc}", file=sys.stderr)
        return 1
    except KeyboardInterrupt:
        print(file=sys.stderr)
        return 130


if __name__ == "__main__":
    raise SystemExit(main())
