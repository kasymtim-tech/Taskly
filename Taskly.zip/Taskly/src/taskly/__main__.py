"""Запуск через ``python -m taskly``."""

from taskly.cli import main

if __name__ == "__main__":
    raise SystemExit(main())
