"""Вывод задач в терминал."""

from __future__ import annotations

from collections.abc import Sequence
from datetime import date, datetime

from taskly.models import DATE_FORMAT, Task

_CODES = {"bold": "1", "dim": "2", "red": "31", "green": "32", "yellow": "33", "cyan": "36"}
_PRIORITY_STYLE = {"high": "red", "medium": "yellow", "low": "dim"}
_HEADERS = ("ID", "", "Задача", "Приоритет", "Срок", "Теги")


def paint(text: str, style: str | None, enabled: bool) -> str:
    if not enabled or not style or not text:
        return text
    return f"\x1b[{_CODES[style]}m{text}\x1b[0m"


def format_due(due: str | None, date_format: str) -> str:
    if not due:
        return ""
    try:
        return datetime.strptime(due, DATE_FORMAT).strftime(date_format)
    except ValueError:
        return due


def render_table(
    tasks: Sequence[Task],
    *,
    date_format: str = DATE_FORMAT,
    color: bool = False,
    today: date | None = None,
) -> str:
    rows: list[list[tuple[str, str | None]]] = []
    for task in tasks:
        if task.done:
            title_style = priority_style = "dim"
            due_style = "dim"
        else:
            title_style = None
            priority_style = _PRIORITY_STYLE.get(task.priority)
            due_style = "red" if task.is_overdue(today) else None
        rows.append(
            [
                (str(task.id), "dim"),
                ("[x]" if task.done else "[ ]", "green" if task.done else None),
                (task.title, title_style),
                (task.priority, priority_style),
                (format_due(task.due, date_format), due_style),
                (", ".join(task.tags), "cyan"),
            ]
        )

    widths = [
        max([len(header)] + [len(row[index][0]) for row in rows])
        for index, header in enumerate(_HEADERS)
    ]
    last = len(_HEADERS) - 1

    def line(cells: Sequence[tuple[str, str | None]]) -> str:
        parts = []
        for index, (text, style) in enumerate(cells):
            padded = text if index == last else text.ljust(widths[index])
            parts.append(paint(padded, style, color))
        return "  ".join(parts).rstrip()

    header = line([(title, "bold") for title in _HEADERS])
    separator = "  ".join("-" * width for width in widths)
    return "\n".join([header, separator, *(line(row) for row in rows)])
