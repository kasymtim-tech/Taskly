"""Загрузка настроек Taskly."""

from __future__ import annotations

import os
from dataclasses import dataclass
from pathlib import Path

from taskly.models import DATE_FORMAT, TasklyError

try:
    import tomllib
except ModuleNotFoundError:  # Python 3.10
    import tomli as tomllib

APP_NAME = "taskly"


class ConfigError(TasklyError):
    """Ошибка в файле настроек."""


@dataclass(frozen=True)
class Config:
    database: Path
    date_format: str = DATE_FORMAT
    color: bool = True


def _appdata() -> Path:
    return Path(os.environ.get("APPDATA") or Path.home() / "AppData" / "Roaming")


def config_path() -> Path:
    if os.name == "nt":
        return _appdata() / APP_NAME / "config.toml"
    return Path.home() / ".config" / APP_NAME / "config.toml"


def default_database() -> Path:
    if os.name == "nt":
        return _appdata() / APP_NAME / "tasks.db"
    return Path.home() / ".local" / "share" / APP_NAME / "tasks.db"


def _default_config_text() -> str:
    if os.name == "nt":
        database = r"database = '%APPDATA%\taskly\tasks.db'"
    else:
        database = 'database = "~/.local/share/taskly/tasks.db"'
    return f'[general]\n{database}\ndate_format = "%Y-%m-%d"\n\n[display]\ncolor = true\n'


def _write_default_config(path: Path) -> None:
    try:
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(_default_config_text(), encoding="utf-8")
    except OSError:
        pass  # Нет прав на запись: работаем со значениями по умолчанию.


def _section(data: dict, name: str, path: Path) -> dict:
    section = data.get(name, {})
    if not isinstance(section, dict):
        raise ConfigError(f"{path}: раздел [{name}] должен быть таблицей.")
    return section


def load_config() -> Config:
    path = config_path()
    if not path.exists():
        _write_default_config(path)

    data: dict = {}
    if path.exists():
        try:
            with path.open("rb") as file:
                data = tomllib.load(file)
        except tomllib.TOMLDecodeError as exc:
            raise ConfigError(f"{path}: {exc}") from exc

    general = _section(data, "general", path)
    display = _section(data, "display", path)

    raw_database = os.environ.get("TASKLY_DB") or general.get("database")
    if raw_database:
        database = Path(os.path.expandvars(os.path.expanduser(str(raw_database))))
    else:
        database = default_database()

    date_format = general.get("date_format", DATE_FORMAT)
    if not isinstance(date_format, str) or not date_format:
        raise ConfigError(f"{path}: параметр date_format должен быть непустой строкой.")

    color = display.get("color", True)
    if not isinstance(color, bool):
        raise ConfigError(f"{path}: параметр color должен быть true или false.")

    return Config(database=database, date_format=date_format, color=color)
