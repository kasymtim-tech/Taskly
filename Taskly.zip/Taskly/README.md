# Taskly

![Python](https://img.shields.io/badge/python-3.10%2B-blue)
![License](https://img.shields.io/badge/license-MIT-green)
![Status](https://img.shields.io/badge/status-stable-brightgreen)

**Taskly** — быстрый и минималистичный менеджер задач для терминала. Все данные хранятся локально в SQLite, работает без интернета и внешних сервисов.

## Возможности

- Добавление, редактирование, завершение и удаление задач
- Приоритеты (`low`, `medium`, `high`) и сроки выполнения
- Теги и фильтрация по статусу, приоритету, тегу и просроченным срокам
- Экспорт и импорт в JSON и CSV
- Цветной вывод в терминале с таблицами
- Локальное хранение данных, без телеметрии

## Требования

- Python 3.10 или новее
- pip 22 или новее

## Установка

```bash
git clone https://github.com/kasymtim-tech/Taskly.git
cd Taskly
python -m venv .venv
source .venv/bin/activate      # Windows: .venv\Scripts\activate
pip install -e .
```

Проверьте установку:

```bash
taskly --version
```

Без установки программу можно запустить и так: `python -m taskly --version` (из папки `src`).

## Быстрый старт

```bash
# Добавить задачу
taskly add "Подготовить отчёт" --priority high --due 2026-11-10 --tag work

# Показать все активные задачи
taskly list

# Отметить задачу выполненной
taskly done 1

# Удалить задачу
taskly rm 1
```

## Команды

| Команда | Описание |
|---------|----------|
| `taskly add <title>` | Создать задачу |
| `taskly list` | Показать задачи |
| `taskly edit <id>` | Изменить задачу |
| `taskly done <id>` | Отметить выполненной |
| `taskly rm <id>` | Удалить задачу |
| `taskly export <file>` | Экспорт в `.json` или `.csv` |
| `taskly import <file>` | Импорт из `.json` или `.csv` |

### Параметры `add` и `edit`

| Параметр | Описание | Значения |
|----------|----------|----------|
| `--priority`, `-p` | Приоритет | `low`, `medium`, `high` (для `add` по умолчанию `medium`) |
| `--due`, `-d` | Срок выполнения | дата в формате `YYYY-MM-DD` |
| `--tag`, `-t` | Тег (можно указывать несколько раз) | любая строка |

Только для `edit`:

| Параметр | Описание |
|----------|----------|
| `--title` | Новое название |
| `--clear-due` | Убрать срок |
| `--clear-tags` | Убрать все теги |

При изменении тегов через `--tag` прежний набор тегов заменяется новым.

```bash
taskly edit 1 --title "Отправить отчёт" --priority low --clear-due
```

### Фильтры `list`

```bash
taskly list --status done      # active (по умолчанию), done или all
taskly list --priority high
taskly list --tag work
taskly list --overdue
```

### Экспорт и импорт

```bash
taskly export backup.json
taskly import backup.json
```

- Экспортируются все задачи, включая выполненные.
- При импорте файл проверяется целиком: если в нём есть ошибка, не добавляется ни одной задачи.
- Импортированные задачи получают новые номера.
- В CSV теги разделяются символом `;`, колонка `done` содержит `true` или `false`.

## Конфигурация

Файл настроек создаётся при первом запуске:

| ОС | Путь |
|----|------|
| Linux / macOS | `~/.config/taskly/config.toml` |
| Windows | `%APPDATA%\taskly\config.toml` |

Пример:

```toml
[general]
database = "~/.local/share/taskly/tasks.db"
date_format = "%Y-%m-%d"

[display]
color = true
```

Путь к базе данных можно переопределить переменной окружения `TASKLY_DB`. Цвета отключаются настройкой `color = false` или переменной `NO_COLOR`; при выводе в файл или через конвейер они не используются автоматически.

## Структура проекта

```text
Taskly/
├── src/
│   └── taskly/
│       ├── __init__.py
│       ├── __main__.py     # запуск через python -m taskly
│       ├── cli.py          # точка входа и разбор команд
│       ├── config.py       # загрузка настроек
│       ├── db.py           # работа с SQLite
│       ├── formatting.py   # вывод в терминал
│       ├── models.py       # модели данных и проверка значений
│       └── transfer.py     # экспорт и импорт
├── tests/
├── pyproject.toml
├── LICENSE
└── README.md
```

## Разработка

```bash
pip install -e ".[dev]"
pytest
ruff check .
```

Перед отправкой изменений убедитесь, что тесты проходят, а линтер не выдаёт замечаний.

## Участие в проекте

1. Сделайте форк репозитория.
2. Создайте ветку: `git checkout -b feature/my-feature`.
3. Зафиксируйте изменения: `git commit -m "Add my feature"`.
4. Отправьте ветку: `git push origin feature/my-feature`.
5. Откройте Pull Request с описанием изменений.

Об ошибках и идеях сообщайте через раздел **Issues**.

## Планы

- [x] Базовые операции с задачами
- [x] Экспорт и импорт
- [ ] Повторяющиеся задачи
- [ ] Напоминания
- [ ] Синхронизация между устройствами

## Лицензия

Проект распространяется по лицензии [MIT](LICENSE).
